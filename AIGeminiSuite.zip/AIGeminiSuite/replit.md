# AI Tools Dashboard

## Overview

This is a full-stack web application that provides AI-powered tools through Google's Gemini API. The application offers four main features: image generation, text generation, document analysis, and an AI chatbot. It's built as a modern single-page application with a React frontend and Express.js backend, designed to demonstrate various AI capabilities in a user-friendly dashboard interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type safety and modern development
- Vite as the build tool for fast development and optimized production builds
- Wouter for lightweight client-side routing

**UI & Styling**
- Tailwind CSS for utility-first styling with custom design tokens
- Shadcn/ui component library built on Radix UI primitives for accessible, customizable components
- Responsive design with mobile-first approach using custom breakpoints

**State Management**
- TanStack Query (React Query) for server state management, caching, and API synchronization
- Local React state for UI-specific state management
- Custom hooks for reusable stateful logic

**Component Architecture**
- Feature-based component organization with separate modules for each AI tool
- Shared UI components in dedicated directory
- Custom hooks for cross-cutting concerns like mobile detection and toast notifications

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for robust API development
- Custom middleware for request logging and error handling
- RESTful API design with clear endpoint organization

**Development Integration**
- Vite middleware integration for seamless development experience
- Hot module replacement and development server proxy
- Custom logging system for request tracking

**API Structure**
- Separate route handlers for each AI service (image generation, text generation, file upload, chat)
- Centralized error handling with proper HTTP status codes
- File upload handling with Multer and validation

### Data Storage Solutions

**Database Setup**
- PostgreSQL as the primary database (configured via Drizzle)
- Neon Database serverless PostgreSQL for cloud deployment
- Database migrations managed through Drizzle Kit

**Data Models**
- Users table for basic user management
- Chat messages with role-based conversation tracking
- Generated images with metadata (prompt, style, size)
- Generated texts with content type and tone tracking
- Uploaded files with analysis results and processing status

**Storage Abstraction**
- Interface-based storage layer allowing for different implementations
- In-memory storage for development and testing
- Database storage for production environments

### Authentication and Authorization

**Current Implementation**
- Basic user schema prepared for future authentication
- Session-based approach with PostgreSQL session storage
- User ID tracking for data association

**Security Considerations**
- File upload validation with type and size restrictions
- Environment variable management for API keys
- CORS and security headers ready for production deployment

### AI Service Integration

**Google Gemini API**
- Multiple API key support with fallback mechanism
- Text generation with customizable parameters (tone, length, content type)
- Image generation with style options
- Document analysis capabilities for various file types
- Conversational AI for chatbot functionality

**Error Handling**
- Graceful fallback for API failures
- User-friendly error messages
- Request retry logic for improved reliability

## External Dependencies

### Core AI Services
- **Google Gemini AI**: Primary AI service for text generation, image generation, and document analysis
- **@google/genai**: Official Google Generative AI SDK for Node.js

### Database & Storage
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe SQL toolkit and query builder
- **connect-pg-simple**: PostgreSQL session store for Express

### Frontend Libraries
- **TanStack Query**: Server state management and caching
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds

### File Processing
- **Multer**: File upload middleware for Express
- **Various file type support**: PDF, DOC, DOCX, TXT, CSV, XLS, XLSX

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Conditional CSS class handling
- **zod**: Runtime type validation and schema definition