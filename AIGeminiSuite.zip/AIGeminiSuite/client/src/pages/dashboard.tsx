import { useState } from "react";
import Sidebar from "@/components/sidebar";
import ImageGeneration from "@/components/image-generation";
import TextGeneration from "@/components/text-generation";
import ReportAnalysis from "@/components/report-analysis";
import Chatbot from "@/components/chatbot";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

type TabType = "image-generation" | "text-generation" | "report-analysis" | "chatbot";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("image-generation");
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const renderActiveTab = () => {
    switch (activeTab) {
      case "image-generation":
        return <ImageGeneration />;
      case "text-generation":
        return <TextGeneration />;
      case "report-analysis":
        return <ReportAnalysis />;
      case "chatbot":
        return <Chatbot />;
      default:
        return <ImageGeneration />;
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-gray-200 p-4 flex items-center justify-between fixed top-0 left-0 right-0 z-40">
        <h1 className="text-lg font-semibold text-gray-900">AI Tools Dashboard</h1>
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64">
            <Sidebar 
              activeTab={activeTab} 
              onTabChange={(tab) => {
                setActiveTab(tab);
                setIsMobileOpen(false);
              }} 
            />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <div className="flex-1 lg:ml-0 pt-16 lg:pt-0">
        {renderActiveTab()}
      </div>
    </div>
  );
}
