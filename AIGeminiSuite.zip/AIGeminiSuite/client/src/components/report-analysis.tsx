import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { CloudUpload, Download, Trash2, BarChart3, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import FileUpload from "@/components/ui/file-upload";
import type { UploadedFile } from "@shared/schema";

export default function ReportAnalysis() {
  const [analysisType, setAnalysisType] = useState("summary");
  const [currentAnalysis, setCurrentAnalysis] = useState<any>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: uploadedFiles = [] } = useQuery<UploadedFile[]>({
    queryKey: ["/api/uploaded-files"],
  });

  const uploadFileMutation = useMutation({
    mutationFn: async (data: { file: File; analysisType: string }) => {
      const formData = new FormData();
      formData.append('file', data.file);
      formData.append('analysisType', data.analysisType);
      formData.append('userId', '');

      const response = await fetch('/api/upload-file', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      return response.json();
    },
    onSuccess: (data: UploadedFile) => {
      queryClient.invalidateQueries({ queryKey: ["/api/uploaded-files"] });
      toast({
        title: "Success",
        description: "File uploaded successfully!",
      });
      
      // Automatically start analysis
      analyzeFileMutation.mutate(data.id);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload file",
        variant: "destructive",
      });
    },
  });

  const analyzeFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await apiRequest("POST", `/api/analyze-file/${fileId}`, {});
      return response.json();
    },
    onSuccess: (data: UploadedFile) => {
      setCurrentAnalysis(data.analysisResult);
      queryClient.invalidateQueries({ queryKey: ["/api/uploaded-files"] });
      toast({
        title: "Success",
        description: "Document analyzed successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to analyze document",
        variant: "destructive",
      });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await apiRequest("DELETE", `/api/uploaded-files/${fileId}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/uploaded-files"] });
      toast({
        title: "Success",
        description: "File deleted successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete file",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (file: File) => {
    uploadFileMutation.mutate({ file, analysisType });
  };

  const handleAnalyze = (fileId: string) => {
    analyzeFileMutation.mutate(fileId);
  };

  const handleDelete = (fileId: string) => {
    deleteFileMutation.mutate(fileId);
  };

  const getFileIcon = (mimetype: string) => {
    if (mimetype.includes('pdf')) return <FileText className="h-5 w-5 text-red-600" />;
    if (mimetype.includes('word')) return <FileText className="h-5 w-5 text-blue-600" />;
    if (mimetype.includes('text')) return <FileText className="h-5 w-5 text-gray-600" />;
    if (mimetype.includes('sheet') || mimetype.includes('excel')) return <FileText className="h-5 w-5 text-green-600" />;
    return <FileText className="h-5 w-5 text-gray-600" />;
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return mb < 1 ? `${(bytes / 1024).toFixed(1)} KB` : `${mb.toFixed(1)} MB`;
  };

  const exportAnalysis = () => {
    if (currentAnalysis) {
      const blob = new Blob([JSON.stringify(currentAnalysis, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `analysis-${Date.now()}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Report Analysis</h2>
        <p className="text-gray-600">Upload and analyze documents, reports, and data files with AI insights</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upload Document</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FileUpload
                onFileSelect={handleFileUpload}
                accept=".pdf,.doc,.docx,.txt,.csv,.xls,.xlsx"
                disabled={uploadFileMutation.isPending}
              />
              
              <div>
                <Label htmlFor="analysisType">Analysis Type</Label>
                <Select value={analysisType} onValueChange={setAnalysisType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summary">Summary & Key Points</SelectItem>
                    <SelectItem value="data-insights">Data Insights</SelectItem>
                    <SelectItem value="sentiment">Sentiment Analysis</SelectItem>
                    <SelectItem value="financial">Financial Analysis</SelectItem>
                    <SelectItem value="custom">Custom Analysis</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Uploaded Files */}
          <Card>
            <CardHeader>
              <CardTitle>Uploaded Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {uploadedFiles.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No files uploaded yet</p>
                ) : (
                  uploadedFiles.map((file) => (
                    <div key={file.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        {getFileIcon(file.mimetype)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{file.filename}</p>
                        <p className="text-xs text-gray-500">
                          {formatFileSize(file.filesize)} • {file.status}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {file.status === "complete" && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setCurrentAnalysis(file.analysisResult)}
                            >
                              View
                            </Button>
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          </>
                        )}
                        {file.status === "processing" && (
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-accent border-t-transparent" />
                        )}
                        {file.status === "error" && (
                          <AlertCircle className="h-4 w-4 text-red-500" />
                        )}
                        {file.status === "uploaded" && (
                          <Button
                            size="sm"
                            onClick={() => handleAnalyze(file.id)}
                            disabled={analyzeFileMutation.isPending}
                          >
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(file.id)}
                          disabled={deleteFileMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analysis Results */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Analysis Results</CardTitle>
              {currentAnalysis && (
                <Button variant="outline" onClick={exportAnalysis}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {currentAnalysis ? (
                <div className="space-y-6">
                  {/* Summary Card */}
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900 mb-2">Document Summary</h4>
                    <p className="text-sm text-blue-800">{currentAnalysis.summary}</p>
                  </div>
                  
                  {/* Key Insights */}
                  {currentAnalysis.insights && (
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Key Insights</h4>
                      <div className="space-y-2">
                        {currentAnalysis.insights.map((insight: string, index: number) => (
                          <div key={index} className="flex items-start space-x-3">
                            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mt-0.5">
                              <CheckCircle className="h-3 w-3 text-white" />
                            </div>
                            <p className="text-sm text-gray-700">{insight}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Metrics */}
                  {currentAnalysis.metrics && (
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Key Metrics</h4>
                      <div className="grid grid-cols-2 gap-4">
                        {Object.entries(currentAnalysis.metrics).map(([key, value]) => (
                          <div key={key} className="bg-gray-50 rounded-lg p-3">
                            <p className="text-sm text-gray-600 capitalize">{key.replace(/([A-Z])/g, ' $1')}</p>
                            <p className="text-lg font-semibold text-gray-900">{String(value)}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-16">
                  <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <p>Upload and analyze a document to see results here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
