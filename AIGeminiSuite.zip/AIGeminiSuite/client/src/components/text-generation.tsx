import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Copy, Download, FileText, Pen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { GeneratedText } from "@shared/schema";

const templates = [
  { name: "Blog Intro", description: "Engaging article openings" },
  { name: "Product Features", description: "Highlight key benefits" },
  { name: "Email Subject", description: "Compelling headlines" },
  { name: "Social Media", description: "Engaging posts" },
  { name: "Press Release", description: "Professional announcements" },
  { name: "FAQ Content", description: "Clear Q&A format" },
];

export default function TextGeneration() {
  const [prompt, setPrompt] = useState("");
  const [contentType, setContentType] = useState("blog-article");
  const [tone, setTone] = useState("professional");
  const [length, setLength] = useState("medium");
  const [currentText, setCurrentText] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: generatedTexts = [] } = useQuery<GeneratedText[]>({
    queryKey: ["/api/generated-texts"],
  });

  const generateTextMutation = useMutation({
    mutationFn: async (data: { prompt: string; contentType: string; tone: string; length: string }) => {
      const response = await apiRequest("POST", "/api/generate-text", {
        prompt: data.prompt,
        contentType: data.contentType,
        tone: data.tone,
        length: data.length,
        userId: null
      });
      return response.json();
    },
    onSuccess: (data: GeneratedText) => {
      setCurrentText(data.generatedText);
      queryClient.invalidateQueries({ queryKey: ["/api/generated-texts"] });
      toast({
        title: "Success",
        description: "Text generated successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate text",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a topic or prompt",
        variant: "destructive",
      });
      return;
    }
    
    generateTextMutation.mutate({ prompt, contentType, tone, length });
  };

  const handleCopy = () => {
    if (currentText) {
      navigator.clipboard.writeText(currentText);
      toast({
        title: "Copied",
        description: "Text copied to clipboard",
      });
    }
  };

  const handleDownload = () => {
    if (currentText) {
      const blob = new Blob([currentText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `generated-text-${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const loadTemplate = (templateName: string) => {
    const templatePrompts = {
      "Blog Intro": "Write an engaging introduction for a blog post about",
      "Product Features": "Create a compelling product description highlighting the key features and benefits of",
      "Email Subject": "Generate catchy email subject lines for",
      "Social Media": "Create an engaging social media post about",
      "Press Release": "Write a professional press release announcing",
      "FAQ Content": "Create frequently asked questions and answers about",
    };
    
    const templatePrompt = templatePrompts[templateName as keyof typeof templatePrompts];
    if (templatePrompt) {
      setPrompt(templatePrompt);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Text Generation</h2>
        <p className="text-gray-600">Generate high-quality content for any purpose using advanced AI</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Input Section */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="contentType">Content Type</Label>
                <Select value={contentType} onValueChange={setContentType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blog-article">Blog Article</SelectItem>
                    <SelectItem value="product-description">Product Description</SelectItem>
                    <SelectItem value="email-copy">Email Copy</SelectItem>
                    <SelectItem value="social-media-post">Social Media Post</SelectItem>
                    <SelectItem value="creative-story">Creative Story</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="tone">Tone</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                    <SelectItem value="formal">Formal</SelectItem>
                    <SelectItem value="creative">Creative</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="length">Length</Label>
                <Select value={length} onValueChange={setLength}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short (100-250 words)</SelectItem>
                    <SelectItem value="medium">Medium (250-500 words)</SelectItem>
                    <SelectItem value="long">Long (500-1000 words)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="prompt">Topic/Prompt</Label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Enter your topic or prompt..."
                  className="h-24 resize-none"
                />
              </div>
              
              <Button 
                onClick={handleGenerate}
                disabled={generateTextMutation.isPending}
                className="w-full bg-secondary hover:bg-purple-700"
              >
                {generateTextMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Pen className="mr-2 h-4 w-4" />
                    Generate Content
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Output Section */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Generated Content</CardTitle>
              {currentText && (
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={handleCopy}>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy
                  </Button>
                  <Button variant="outline" onClick={handleDownload}>
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <div className="min-h-96 bg-gray-50 rounded-lg p-6 border border-gray-200">
                {currentText ? (
                  <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                    {currentText}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 mt-32">
                    <FileText className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                    <p>Generated content will appear here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Content Templates */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {templates.map((template) => (
                  <button
                    key={template.name}
                    onClick={() => loadTemplate(template.name)}
                    className="p-3 text-left border border-gray-200 rounded-lg hover:border-secondary hover:bg-purple-50 transition-colors duration-200"
                  >
                    <div className="font-medium text-gray-900">{template.name}</div>
                    <div className="text-sm text-gray-500">{template.description}</div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
