import { Brain, Check } from "lucide-react";
import { cn } from "@/lib/utils";

type TabType = "image-generation" | "text-generation" | "report-analysis" | "chatbot";

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const navigationItems = [
  {
    id: "image-generation" as TabType,
    label: "Image Generation",
    icon: "fas fa-image"
  },
  {
    id: "text-generation" as TabType,
    label: "Text Generation", 
    icon: "fas fa-pen-fancy"
  },
  {
    id: "report-analysis" as TabType,
    label: "Report Analysis",
    icon: "fas fa-chart-line"
  },
  {
    id: "chatbot" as TabType,
    label: "AI Chatbot",
    icon: "fas fa-comments"
  }
];

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <div className="w-64 bg-white shadow-lg border-r border-gray-200 h-full">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center">
            <Brain className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">AI Tools</h1>
            <p className="text-sm text-gray-500">Gemini Integration</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navigationItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={cn(
              "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors duration-200 font-medium",
              activeTab === item.id
                ? "bg-primary text-white"
                : "text-gray-700 hover:bg-gray-100"
            )}
          >
            <i className={`${item.icon} text-lg`} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      
      {/* Status */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
        <div className="flex items-center space-x-3 text-sm text-gray-600">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>API Connected</span>
        </div>
      </div>
    </div>
  );
}
