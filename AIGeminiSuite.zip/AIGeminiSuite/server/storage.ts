import { 
  type User, 
  type InsertUser, 
  type ChatMessage, 
  type InsertChatMessage,
  type GeneratedImage,
  type InsertGeneratedImage,
  type GeneratedText,
  type InsertGeneratedText,
  type UploadedFile,
  type InsertUploadedFile
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat messages
  getChatMessages(userId?: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatMessages(userId?: string): Promise<void>;
  
  // Generated images
  getGeneratedImages(userId?: string): Promise<GeneratedImage[]>;
  createGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;
  
  // Generated texts
  getGeneratedTexts(userId?: string): Promise<GeneratedText[]>;
  createGeneratedText(text: InsertGeneratedText): Promise<GeneratedText>;
  
  // Uploaded files
  getUploadedFiles(userId?: string): Promise<UploadedFile[]>;
  createUploadedFile(file: InsertUploadedFile): Promise<UploadedFile>;
  updateFileAnalysis(id: string, analysisResult: any, status: string): Promise<UploadedFile | undefined>;
  deleteUploadedFile(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private chatMessages: Map<string, ChatMessage>;
  private generatedImages: Map<string, GeneratedImage>;
  private generatedTexts: Map<string, GeneratedText>;
  private uploadedFiles: Map<string, UploadedFile>;

  constructor() {
    this.users = new Map();
    this.chatMessages = new Map();
    this.generatedImages = new Map();
    this.generatedTexts = new Map();
    this.uploadedFiles = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getChatMessages(userId?: string): Promise<ChatMessage[]> {
    const messages = Array.from(this.chatMessages.values());
    if (userId) {
      return messages.filter(msg => msg.userId === userId);
    }
    return messages.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage,
      userId: insertMessage.userId || null,
      id, 
      timestamp: new Date() 
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async clearChatMessages(userId?: string): Promise<void> {
    if (userId) {
      const entriesToDelete: string[] = [];
      const entries = Array.from(this.chatMessages.entries());
      for (const [id, message] of entries) {
        if (message.userId === userId) {
          entriesToDelete.push(id);
        }
      }
      entriesToDelete.forEach(id => this.chatMessages.delete(id));
    } else {
      this.chatMessages.clear();
    }
  }

  async getGeneratedImages(userId?: string): Promise<GeneratedImage[]> {
    const images = Array.from(this.generatedImages.values());
    if (userId) {
      return images.filter(img => img.userId === userId);
    }
    return images.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createGeneratedImage(insertImage: InsertGeneratedImage): Promise<GeneratedImage> {
    const id = randomUUID();
    const image: GeneratedImage = { 
      ...insertImage,
      userId: insertImage.userId || null,
      style: insertImage.style || null,
      size: insertImage.size || null,
      id, 
      timestamp: new Date() 
    };
    this.generatedImages.set(id, image);
    return image;
  }

  async getGeneratedTexts(userId?: string): Promise<GeneratedText[]> {
    const texts = Array.from(this.generatedTexts.values());
    if (userId) {
      return texts.filter(text => text.userId === userId);
    }
    return texts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createGeneratedText(insertText: InsertGeneratedText): Promise<GeneratedText> {
    const id = randomUUID();
    const text: GeneratedText = { 
      ...insertText,
      userId: insertText.userId || null,
      contentType: insertText.contentType || null,
      tone: insertText.tone || null,
      length: insertText.length || null,
      id, 
      timestamp: new Date() 
    };
    this.generatedTexts.set(id, text);
    return text;
  }

  async getUploadedFiles(userId?: string): Promise<UploadedFile[]> {
    const files = Array.from(this.uploadedFiles.values());
    if (userId) {
      return files.filter(file => file.userId === userId);
    }
    return files.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createUploadedFile(insertFile: InsertUploadedFile): Promise<UploadedFile> {
    const id = randomUUID();
    const file: UploadedFile = { 
      ...insertFile,
      userId: insertFile.userId || null,
      analysisType: insertFile.analysisType || null,
      analysisResult: insertFile.analysisResult || null,
      id, 
      status: "uploaded",
      timestamp: new Date() 
    };
    this.uploadedFiles.set(id, file);
    return file;
  }

  async updateFileAnalysis(id: string, analysisResult: any, status: string): Promise<UploadedFile | undefined> {
    const file = this.uploadedFiles.get(id);
    if (file) {
      const updatedFile = { ...file, analysisResult, status };
      this.uploadedFiles.set(id, updatedFile);
      return updatedFile;
    }
    return undefined;
  }

  async deleteUploadedFile(id: string): Promise<boolean> {
    return this.uploadedFiles.delete(id);
  }
}

export const storage = new MemStorage();
