import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertChatMessageSchema, 
  insertGeneratedImageSchema, 
  insertGeneratedTextSchema,
  insertUploadedFileSchema 
} from "@shared/schema";
import { 
  generateText, 
  generateImage, 
  analyzeDocument, 
  chatWithAI 
} from "./services/gemini";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, TXT, CSV, XLS, XLSX files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Image Generation Routes
  app.post("/api/generate-image", async (req, res) => {
    try {
      const validatedData = insertGeneratedImageSchema.parse(req.body);
      
      // Generate image using Gemini
      const imageUrl = await generateImage(validatedData.prompt, validatedData.style || undefined);
      
      // Save to storage
      const generatedImage = await storage.createGeneratedImage({
        ...validatedData,
        imageUrl
      });
      
      res.json(generatedImage);
    } catch (error) {
      console.error("Image generation error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate image" 
      });
    }
  });

  app.get("/api/generated-images", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const images = await storage.getGeneratedImages(userId);
      res.json(images);
    } catch (error) {
      console.error("Get images error:", error);
      res.status(500).json({ message: "Failed to fetch generated images" });
    }
  });

  // Text Generation Routes
  app.post("/api/generate-text", async (req, res) => {
    try {
      const validatedData = insertGeneratedTextSchema.parse(req.body);
      
      // Generate text using Gemini
      const generatedText = await generateText(
        validatedData.prompt, 
        validatedData.contentType || undefined, 
        validatedData.tone || undefined, 
        validatedData.length || undefined
      );
      
      // Save to storage
      const textResult = await storage.createGeneratedText({
        ...validatedData,
        generatedText
      });
      
      res.json(textResult);
    } catch (error) {
      console.error("Text generation error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate text" 
      });
    }
  });

  app.get("/api/generated-texts", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const texts = await storage.getGeneratedTexts(userId);
      res.json(texts);
    } catch (error) {
      console.error("Get texts error:", error);
      res.status(500).json({ message: "Failed to fetch generated texts" });
    }
  });

  // File Upload and Analysis Routes
  app.post("/api/upload-file", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const uploadedFile = await storage.createUploadedFile({
        userId: req.body.userId,
        filename: req.file.originalname,
        filepath: req.file.path,
        filesize: req.file.size,
        mimetype: req.file.mimetype,
        analysisType: req.body.analysisType,
        analysisResult: null
      });

      res.json(uploadedFile);
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to upload file" 
      });
    }
  });

  app.post("/api/analyze-file/:fileId", async (req, res) => {
    try {
      const { fileId } = req.params;
      const files = await storage.getUploadedFiles();
      const file = files.find(f => f.id === fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Update status to processing
      await storage.updateFileAnalysis(fileId, null, "processing");

      try {
        // Analyze document using Gemini
        const analysisResult = await analyzeDocument(file.filepath, file.analysisType || "summary");
        
        // Update with results
        const updatedFile = await storage.updateFileAnalysis(fileId, analysisResult, "complete");
        
        res.json(updatedFile);
      } catch (analysisError) {
        // Update status to error
        await storage.updateFileAnalysis(fileId, { error: "Analysis failed" }, "error");
        throw analysisError;
      }
    } catch (error) {
      console.error("File analysis error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to analyze file" 
      });
    }
  });

  app.get("/api/uploaded-files", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const files = await storage.getUploadedFiles(userId);
      res.json(files);
    } catch (error) {
      console.error("Get files error:", error);
      res.status(500).json({ message: "Failed to fetch uploaded files" });
    }
  });

  app.delete("/api/uploaded-files/:fileId", async (req, res) => {
    try {
      const { fileId } = req.params;
      const files = await storage.getUploadedFiles();
      const file = files.find(f => f.id === fileId);
      
      if (file) {
        // Delete physical file
        if (fs.existsSync(file.filepath)) {
          fs.unlinkSync(file.filepath);
        }
      }
      
      const deleted = await storage.deleteUploadedFile(fileId);
      
      if (deleted) {
        res.json({ message: "File deleted successfully" });
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      console.error("Delete file error:", error);
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Chat Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      
      // Save user message
      const userMessage = await storage.createChatMessage(validatedData);
      
      // Get chat history for context
      const chatHistory = await storage.getChatMessages(validatedData.userId || undefined);
      
      // Generate AI response
      const aiResponse = await chatWithAI(validatedData.message, chatHistory);
      
      // Save AI response
      const aiMessage = await storage.createChatMessage({
        userId: validatedData.userId,
        message: aiResponse,
        role: "assistant"
      });
      
      res.json({
        userMessage,
        aiMessage
      });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process chat message" 
      });
    }
  });

  app.get("/api/chat-messages", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const messages = await storage.getChatMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error("Get chat messages error:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.delete("/api/chat-messages", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      await storage.clearChatMessages(userId);
      res.json({ message: "Chat history cleared successfully" });
    } catch (error) {
      console.error("Clear chat error:", error);
      res.status(500).json({ message: "Failed to clear chat history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
