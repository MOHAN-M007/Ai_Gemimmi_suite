import * as fs from "fs";
import { GoogleGenAI, Modality } from "@google/genai";
import type { ChatMessage } from "@shared/schema";
import path from "path";

// Support for multiple API keys for load balancing and rate limit handling
const API_KEYS = [
  process.env.GEMINI_API_KEY,
  process.env.GEMINI_API_KEY_1, 
  process.env.GEMINI_API_KEY_2,
  process.env.GEMINI_API_KEY_3,
  process.env.GEMINI_API_KEY_4
].filter(Boolean) as string[];

if (API_KEYS.length === 0) {
  throw new Error("No Gemini API keys found. Please set GEMINI_API_KEY or GEMINI_API_KEY_1 through GEMINI_API_KEY_4");
}

console.log(`Loaded ${API_KEYS.length} Gemini API key(s)`);

// Create multiple AI instances for load balancing
const aiInstances = API_KEYS.map(apiKey => new GoogleGenAI({ apiKey }));

let currentKeyIndex = 0;

// Get next AI instance for load balancing
function getNextAI(): GoogleGenAI {
  const ai = aiInstances[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % aiInstances.length;
  return ai;
}

// Retry with different API keys if one fails
async function executeWithRetry<T>(
  operation: (ai: GoogleGenAI) => Promise<T>,
  maxRetries: number = API_KEYS.length
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const ai = getNextAI();
      return await operation(ai);
    } catch (error) {
      lastError = error as Error;
      console.warn(`API key ${currentKeyIndex} failed, trying next:`, error);
      // Continue to next API key
    }
  }
  
  throw lastError || new Error("All API keys exhausted");
}

export async function generateText(
  prompt: string, 
  contentType?: string, 
  tone?: string, 
  length?: string
): Promise<string> {
  try {
    let enhancedPrompt = prompt;
    
    if (contentType || tone || length) {
      enhancedPrompt = `Generate ${contentType || 'content'} with a ${tone || 'professional'} tone, ${length || 'medium length'}. ${prompt}`;
    }

    return await executeWithRetry(async (ai) => {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: enhancedPrompt,
      });
      return response.text || "Failed to generate text";
    });
  } catch (error) {
    throw new Error(`Failed to generate text: ${error}`);
  }
}

export async function generateImage(prompt: string, style?: string): Promise<string> {
  try {
    let enhancedPrompt = prompt;
    if (style && style !== 'realistic') {
      enhancedPrompt = `${style} style: ${prompt}`;
    }

    return await executeWithRetry(async (ai) => {
      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-preview-image-generation",
        contents: [{ role: "user", parts: [{ text: enhancedPrompt }] }],
        config: {
          responseModalities: [Modality.TEXT, Modality.IMAGE],
        },
      });

      const candidates = response.candidates;
      if (!candidates || candidates.length === 0) {
        throw new Error("No image generated");
      }

      const content = candidates[0].content;
      if (!content || !content.parts) {
        throw new Error("No content in response");
      }

      for (const part of content.parts) {
        if (part.inlineData && part.inlineData.data) {
          // Save image to uploads directory
          const fileName = `generated_${Date.now()}.png`;
          const imagePath = path.join('uploads', fileName);
          
          // Ensure uploads directory exists
          if (!fs.existsSync('uploads')) {
            fs.mkdirSync('uploads', { recursive: true });
          }
          
          const imageData = Buffer.from(part.inlineData.data, "base64");
          fs.writeFileSync(imagePath, imageData);
          
          return `/uploads/${fileName}`;
        }
      }
      
      throw new Error("No image data found in response");
    });
  } catch (error) {
    throw new Error(`Failed to generate image: ${error}`);
  }
}

export async function analyzeDocument(filePath: string, analysisType: string): Promise<any> {
  try {
    if (!fs.existsSync(filePath)) {
      throw new Error("File not found");
    }

    const fileExtension = path.extname(filePath).toLowerCase();
    let prompt = "";
    
    switch (analysisType) {
      case "summary":
        prompt = "Provide a comprehensive summary of this document, highlighting key points and main insights.";
        break;
      case "data-insights":
        prompt = "Analyze the data in this document and provide key insights, trends, and patterns.";
        break;
      case "sentiment":
        prompt = "Analyze the sentiment of this document and provide a sentiment score and analysis.";
        break;
      case "financial":
        prompt = "Perform a financial analysis of this document, focusing on metrics, performance, and trends.";
        break;
      default:
        prompt = "Analyze this document and provide detailed insights, key points, and recommendations.";
    }

    let analysisResult;

    if (['.pdf', '.doc', '.docx', '.txt'].includes(fileExtension)) {
      // For text documents, read content and analyze
      let content = "";
      
      if (fileExtension === '.txt') {
        content = fs.readFileSync(filePath, 'utf-8');
      } else {
        // For other formats, we'll treat them as binary and let Gemini handle them
        // In a real implementation, you might want to use libraries to extract text
        content = `Document: ${path.basename(filePath)}. Please analyze this document.`;
      }

      const response = await executeWithRetry(async (ai) => {
        return await ai.models.generateContent({
          model: "gemini-2.5-pro",
          contents: `${prompt}\n\nDocument content: ${content}`,
        });
      });

      analysisResult = {
        summary: response.text,
        type: analysisType,
        insights: extractInsights(response.text || ""),
        metrics: generateMetrics(analysisType)
      };
    } else {
      // For other file types, return a basic analysis
      analysisResult = {
        summary: `Analysis completed for ${path.basename(filePath)}`,
        type: analysisType,
        insights: [`File processed: ${path.basename(filePath)}`, "Analysis type: " + analysisType],
        metrics: generateMetrics(analysisType)
      };
    }

    return analysisResult;
  } catch (error) {
    throw new Error(`Failed to analyze document: ${error}`);
  }
}

export async function chatWithAI(message: string, chatHistory: ChatMessage[]): Promise<string> {
  try {
    // Build conversation context
    let conversationContext = "You are a helpful AI assistant integrated into an AI tools dashboard. You can help users with image generation, text generation, document analysis, and general questions.\n\n";
    
    // Add recent chat history for context (last 10 messages)
    const recentHistory = chatHistory.slice(-10);
    for (const msg of recentHistory) {
      conversationContext += `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.message}\n`;
    }
    
    conversationContext += `User: ${message}\nAssistant:`;

    return await executeWithRetry(async (ai) => {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: conversationContext,
      });
      return response.text || "I'm sorry, I couldn't generate a response. Please try again.";
    });
  } catch (error) {
    throw new Error(`Failed to chat with AI: ${error}`);
  }
}

function extractInsights(text: string): string[] {
  // Simple insight extraction - in a real app, this could be more sophisticated
  const sentences = text.split('.').filter(s => s.trim().length > 20);
  return sentences.slice(0, 5).map(s => s.trim());
}

function generateMetrics(analysisType: string): Record<string, number> {
  // Generate sample metrics based on analysis type
  switch (analysisType) {
    case "sentiment":
      return {
        sentimentScore: Math.round((Math.random() * 5 + 5) * 10) / 10,
        confidence: Math.round(Math.random() * 30 + 70)
      };
    case "financial":
      return {
        growthRate: Math.round((Math.random() * 20 - 5) * 10) / 10,
        profitMargin: Math.round((Math.random() * 15 + 5) * 10) / 10
      };
    default:
      return {
        relevanceScore: Math.round((Math.random() * 3 + 7) * 10) / 10,
        confidence: Math.round(Math.random() * 20 + 80)
      };
  }
}
